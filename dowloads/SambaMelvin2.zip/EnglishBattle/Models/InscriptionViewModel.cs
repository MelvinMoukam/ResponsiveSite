﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace EnglishBattle.Models
{
    public class InscriptionViewModel
    {
        [Required]
        [Display(Name = "Nom")]
        public string Nom { get; set; }
        
        [Required]
        [Display(Name = "Prénom")]
        public string Prenom { get; set; }

        [Required]
        [Display(Name = "Courrier électronique")]
        [EmailAddress]
        public string Email { get; set; }

        [Display(Name = "Ville")]
        public int idVille { get; set; }
        public List<SelectListItem> Villes { get; set; }

        [Required]
        [Display(Name = "Niveau de jeu")]
        public int Niveau { get; set; }
        public List<SelectListItem> Niveaux { get; set; }

        [Required]
        [Display(Name = "Mot de passe")]
        [DataType(DataType.Password)]
        [StringLength(15, ErrorMessage = "Le password doit comporter au moins {2} caractères.", MinimumLength = 6)]
        public string Password { get; set; }

        [Required]
        [Display(Name = "Confirmer le mot de passe")]
        [DataType(DataType.Password)]
        [System.ComponentModel.DataAnnotations.Compare("Password", ErrorMessage = "La confirmation du mot de passe ne correspond pas.")]
        public string ConfirmationPassword { get; set; }
    }
}
﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace EnglishBattle.Models
{
    public class PartieViewModel
    {

        public int id { get; set; }
        public List<SelectListItem> Verbe { get; set; }

        [Required]
        [Display(Name = "Participe passé")]
        public string participePasse { get; set; }

        [Required]
        [Display(Name = "Preterit")]
        public string preterit { get; set; }
        public List<SelectListItem> Verbes { get; internal set; }
        public string traduction { get; set; }
    }
}

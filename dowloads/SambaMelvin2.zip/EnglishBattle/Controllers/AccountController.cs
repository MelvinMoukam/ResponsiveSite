﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using EnglishBattle.Data;
using EnglishBattle.Data.Services;
using EnglishBattle.Models;

namespace EnglishBattle.Controllers
{


    public class AccountController : Controller
    {
        // GET: Account
        public ActionResult Register()
        {
            // crée un VilleService
            EnglishBattleEntities ebe = new EnglishBattleEntities();

            VilleService villeService = new VilleService(ebe);
            List<Ville> villes = villeService.GetList();

            // crée le model
            InscriptionViewModel model = new InscriptionViewModel();

            // crée l'objet pour la liste ville
            model.Villes = new List<SelectListItem>();

            // converti la liste generique
            foreach(Ville ville in villes) {
                SelectListItem item = new SelectListItem();
                item.Value = ville.id.ToString();
                item.Text = ville.nom;

                /// ajoute l'item dans la liste
                model.Villes.Add(item);
            }

            // crée l'objet pour la liste niveau
            model.Niveaux = new List<SelectListItem>();

            // ajoute les niveaux dans la liste Niveaux
            SelectListItem niveau1 = new SelectListItem() { Value = "1", Text = "Faux débutant (1)" };
            SelectListItem niveau2 = new SelectListItem() { Value = "2", Text = "Débutant (2)" };
            SelectListItem niveau3 = new SelectListItem() { Value = "3", Text = "Novice (3)" };
            SelectListItem niveau4 = new SelectListItem() { Value = "4", Text = "Intermédiaire (4)" };
            SelectListItem niveau5 = new SelectListItem() { Value = "5", Text = "Courant (5)" };
            SelectListItem niveau6 = new SelectListItem() { Value = "6", Text = "Avancé (6)" };
            SelectListItem niveau7 = new SelectListItem() { Value = "7", Text = "Bilingue (7)" };

            // ajoute les niveaux à la liste
            model.Niveaux.Add(niveau1);
            model.Niveaux.Add(niveau2);
            model.Niveaux.Add(niveau3);
            model.Niveaux.Add(niveau4);
            model.Niveaux.Add(niveau5);
            model.Niveaux.Add(niveau6);
            model.Niveaux.Add(niveau7);

            ViewBag.Essai = "Methode GET";
            // renvoie la vue avec un modele
            return View(model);
        }

        public ActionResult Login()
        {
            // renvoie la vue
            return View();
        }


        [HttpPost]
        public ActionResult Login(ConnexionViewModel model)
        {
            // vérification coté serveur que les données soit valide
            if (ModelState.IsValid)
            {
                // ici on vérifie si le joueur existe en base de données
                JoueurService joueurService = new JoueurService(new EnglishBattle.Data.EnglishBattleEntities());

                Joueur joueur = joueurService.GetItem(model.Email, model.Password);

                if (joueur != null)
                {
                    // ajoute le joueur dans la session
                    Session["joueur"] = joueur;
                    Session["prenom"] = joueur.prenom;

                    // effectue un redirect avec l'url Home/Index
                    return RedirectToAction("Index", "Home");
                }
            }

            return View();
        }

        public ActionResult Logout()
        {
            Session.Abandon();
            Session.Clear();
            Session.RemoveAll();
            return RedirectToAction("Index", "Home");
        }

       
        [HttpPost]
        public ActionResult Register(InscriptionViewModel model)
        {

            // vérification coté serveur que les données sont valides
            if (ModelState.IsValid)
            {
                // ici on enregistre le joueur en base de données
                JoueurService joueurService = new JoueurService(new EnglishBattle.Data.EnglishBattleEntities());

                // créé un joueur
                Joueur joueur = new Joueur();

                joueur.nom = model.Nom;
                joueur.prenom = model.Prenom;
                joueur.email = model.Email;
                joueur.idVille = model.idVille;
                joueur.niveau = model.Niveau;
                joueur.motDePasse = model.Password;

                joueurService.Insert(joueur);

                // effectue un redirect avec l'url Home/Index
                return RedirectToAction("Index", "Home");
            }

            return View();
        }

    }

}
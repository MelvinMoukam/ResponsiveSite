﻿using EnglishBattle.Data;
using EnglishBattle.Data.Services;
using EnglishBattle.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;


namespace EnglishBattle.Controllers
{
    public class PartieController : Controller
    {
        private List<Verbe> verbes;

        public static class Global
        {
            public static int index { get; set; }
            public static string participepassee { get; set; }
            public static string preterit { get; set; }
            public static string traduction { get; set; }
            public static int cptwinner = 0;
            public static int cptloser = 3;
            public static int numquestion = 1;
        }
        public ActionResult Index()
        {
            if (Session["joueur"] != null)
            {
                // crée un VerbeService
                EnglishBattleEntities ebe = new EnglishBattleEntities();

                VerbeService verbeService = new VerbeService(ebe);
                List<Verbe> verbes = verbeService.GetList();
                //Verbe verbeRandom = RandomVerbe(verbes);
                Random random = new Random();

                // crée le model
                PartieViewModel model = new PartieViewModel();

                    // crée l'objet pour la liste de verbe
                    model.Verbes = new List<SelectListItem>();
                // converti la liste generique
                foreach (Verbe verbe in verbes)
                {
                    SelectListItem item = new SelectListItem();
                    item.Value = verbe.id.ToString();
                    item.Text = verbe.baseVerbale.ToString();
                    item.Text = verbe.participePasse.ToString();
                    item.Text = verbe.preterit.ToString();
                    item.Text = verbe.traduction.ToString();

                    /// ajoute l'item dans la liste
                    model.Verbes.Add(item);
                }

                Global.index = RandomVerbe(verbes).id;
                Global.participepassee = RandomVerbe(verbes).participePasse;
                Global.preterit = RandomVerbe(verbes).preterit;
                Global.traduction = RandomVerbe(verbes).traduction;

                ViewBag.Verbe = RandomVerbe(verbes).baseVerbale;
                ViewBag.Traduction = Global.traduction;
                ViewBag.Participe = Global.participepassee;
                ViewBag.Preterit = Global.preterit;
                ViewBag.Score = Global.cptwinner;
                ViewBag.Nquestion = Global.numquestion;

                // renvoie la vue avec un model

                return View(model);

            } else
            {
                return RedirectToAction("Login", "Account");
            }


        }

        [HttpPost]
        public ActionResult Index(PartieViewModel model)
        {
            do
            {
                // vérification coté serveur que les données soit valide
                if (ModelState.IsValid)
                {
                    // ici on vérifie si le verbe entré existe en base de données

                    {
                        if (Global.preterit == model.participePasse && Global.participepassee == model.preterit)
                        {
                            Global.cptwinner++;
                            Global.numquestion++;
                            return RedirectToAction("Index", "Partie");
                        }
                        else
                        {
                            return RedirectToAction("Again", "Partie");
                        }
                    }
                }
                return View();
            } while (Global.cptwinner < 5);

        }

    

        public Verbe RandomVerbe(List<Verbe> verbes)
        {
            int indexVerbe;
            Random randomNumber = new Random();
            indexVerbe = randomNumber.Next(verbes.Count);

            //verbes.RemoveAt(indexVerbe);
            return verbes[indexVerbe];
        }

        public ActionResult Again()
        {
            return View();
        }

    }
}
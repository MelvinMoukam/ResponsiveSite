﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EnglishBattle.Data.Services
{
    public class QuestionService
    {
        private EnglishBattleEntities context;

        public QuestionService(EnglishBattleEntities context)
        {
            this.context = context;
        }

        /// <summary>
        /// Retourne un objet métier
        /// </summary>
        /// <param name="id">id</param>
        /// <returns>objet métier</returns>
        public Question GetItem(int id)
        {
            using (context)
            {
                return context.Question.Find(id);
            }
        }

        public List<Question> GetList()
        {
            using (context)
            {
                return context.Question.ToList();

            }
        }

        public void Insert(Question question)
        {
            using (context)
            {
                context.Question.Add(question);
                context.SaveChanges();
            }
        }

        public void Update(Question question)
        {
            using (context)
            {
                context.Entry(question).State = System.Data.Entity.EntityState.Modified;
                context.SaveChanges();
            }
        }

        public void Delete(Question question)
        {
            using (context)
            {
                context.Entry(question).State = System.Data.Entity.EntityState.Deleted;
                context.SaveChanges();
            }
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EnglishBattle.Data.Services
{
    public class JoueurService
    {
        private EnglishBattleEntities context;

        public JoueurService(EnglishBattleEntities context)
        {
            this.context = context;
        }

        /// <summary>
        /// Retourne un objet métier
        /// </summary>
        /// <param name="id">id</param>
        /// <returns>objet métier</returns>
        public Joueur GetItem(int id)
        {
            using (context)
            {
                return context.Joueur.Find(id);
            }
        }

        public Joueur GetItem(string email, string password)
        {
            using (context)
            {
                IQueryable<Joueur> joueurs = from joueur in context.Joueur
                                                       where joueur.email == email
                                                       && joueur.motDePasse == password
                                                       select joueur;

                return joueurs.FirstOrDefault();
            }
        }

        public List<Joueur> GetList()
        {
            using (context)
            {
                return context.Joueur.ToList();

            }
        }

        public void Insert(Joueur joueur)
        {
            using (context)
            {
                context.Joueur.Add(joueur);
                context.SaveChanges();
            }
        }

        public void Update(Joueur joueur)
        {
            using (context)
            {
                context.Entry(joueur).State = System.Data.Entity.EntityState.Modified;
                context.SaveChanges();
            }
        }

        public void Delete(Joueur joueur)
        {
            using (context)
            {
                context.Entry(joueur).State = System.Data.Entity.EntityState.Deleted;
                context.SaveChanges();
            }
        }
    }
}

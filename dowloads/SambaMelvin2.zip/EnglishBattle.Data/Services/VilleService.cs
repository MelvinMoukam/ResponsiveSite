﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EnglishBattle.Data.Services
{
    public class VilleService
    {
        private EnglishBattleEntities context;

        public VilleService(EnglishBattleEntities context)
        {
            this.context = context;
        }

        /// <summary>
        /// Retourne un objet métier
        /// </summary>
        /// <param name="id">id</param>
        /// <returns>objet métier</returns>
        public Ville GetItem(int id)
        {
            using (context)
            {
                return context.Ville.Find(id);
            }
        }

        public List<Ville> GetList()
        {
            using (context)

            {
                return context.Ville.ToList();

            }
        }

        public void Insert(Ville ville)
        {
            using (context)
            {
                context.Ville.Add(ville);
                context.SaveChanges();
            }
        }

        public void Update(Ville ville)
        {
            using (context)
            {
                context.Entry(ville).State = System.Data.Entity.EntityState.Modified;
                context.SaveChanges();
            }
        }

        public void Delete(Ville ville)
        {
            using (context)
            {
                context.Entry(ville).State = System.Data.Entity.EntityState.Deleted;
                context.SaveChanges();
            }
        }
    }
}

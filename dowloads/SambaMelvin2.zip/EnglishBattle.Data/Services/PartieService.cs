﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EnglishBattle.Data.Services
{
    public class PartieService
    {
        private EnglishBattleEntities context;

        public PartieService(EnglishBattleEntities context)
        {
            this.context = context;
        }

        /// <summary>
        /// Retourne un objet métier
        /// </summary>
        /// <param name="id">id</param>
        /// <returns>objet métier</returns>
        public Partie GetItem(int id)
        {
            using (context)
            {
                return context.Partie.Find(id);
            }
        }

        public List<Partie> GetList()
        {
            using (context)
            {
                return context.Partie.ToList();

            }
        }

        public void Insert(Partie partie)
        {
            using (context)
            {
                context.Partie.Add(partie);
                context.SaveChanges();
            }
        }

        public void Update(Partie partie)
        {
            using (context)
            {
                context.Entry(partie).State = System.Data.Entity.EntityState.Modified;
                context.SaveChanges();
            }
        }

        public void Delete(Partie partie)
        {
            using (context)
            {
                context.Entry(partie).State = System.Data.Entity.EntityState.Deleted;
                context.SaveChanges();
            }
        }
    }
}
